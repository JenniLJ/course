
public class ClassroomTesterJarrell {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Classroom compSciLab = new Classroom("8", "17", "Ankeny", "Computer Lab", 25);
		System.out.println(compSciLab);//compSciLab.toString();
		
		Classroom bioLab = new Classroom("3", "28a", "Ankeny", "Science Lab", 22);
		System.out.println(bioLab);//bioLab.toString();
		
		Classroom litRoom = new Classroom("2", "12", "Urban", "Classroom", 18);
		System.out.println(litRoom);//litRoom.toString();
	}

}
